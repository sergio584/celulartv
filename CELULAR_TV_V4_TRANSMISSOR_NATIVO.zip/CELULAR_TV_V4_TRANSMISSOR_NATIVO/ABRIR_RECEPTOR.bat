@echo off
title CELULAR TV V4 - RECEPTOR
color 0B
cd /d "%~dp0"
py servidor.py 2>nul || python servidor.py
pause
