package com.gpt.celulartv;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

public class CaptureService extends Service {
    private static final String CHANNEL = "celular_tv_projection";

    private MediaProjection projection;
    private ImageReader reader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private final AtomicBoolean sending = new AtomicBoolean(false);
    private String frameUrl;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);

        Notification notification = builder
                .setContentTitle("Celular → TV")
                .setContentText("Transmitindo a tela para a TV")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .build();

        startForeground(77, notification);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL,
                    "Transmissão de tela",
                    NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        stopProjection();

        frameUrl = intent.getStringExtra("frameUrl");
        int resultCode = intent.getIntExtra("resultCode", -1);
        Intent data = intent.getParcelableExtra("projectionData");

        MediaProjectionManager manager =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        projection = manager.getMediaProjection(resultCode, data);

        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf();
            }
        }, new Handler(getMainLooper()));

        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        if (Build.VERSION.SDK_INT >= 30) {
            int width = wm.getCurrentWindowMetrics().getBounds().width();
            int height = wm.getCurrentWindowMetrics().getBounds().height();
            startCapture(width, height, getResources().getDisplayMetrics().densityDpi);
        } else {
            wm.getDefaultDisplay().getRealMetrics(dm);
            startCapture(dm.widthPixels, dm.heightPixels, dm.densityDpi);
        }

        return START_NOT_STICKY;
    }

    private void startCapture(int sourceWidth, int sourceHeight, int densityDpi) {
        int maxSide = 1280;
        float scale = Math.min(1f, maxSide / (float)Math.max(sourceWidth, sourceHeight));
        int width = Math.max(2, Math.round(sourceWidth * scale));
        int height = Math.max(2, Math.round(sourceHeight * scale));

        // RGBA_8888 + latest-frame strategy avoids queue buildup.
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);

        captureThread = new HandlerThread("celular-tv-capture");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());

        projection.createVirtualDisplay(
                "CelularTV",
                width,
                height,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(),
                null,
                captureHandler
        );

        reader.setOnImageAvailableListener(r -> {
            Image image = null;
            try {
                image = r.acquireLatestImage();
                if (image == null || sending.getAndSet(true)) return;

                Image.Plane plane = image.getPlanes()[0];
                ByteBuffer buffer = plane.getBuffer();

                int pixelStride = plane.getPixelStride();
                int rowStride = plane.getRowStride();
                int rowPadding = rowStride - pixelStride * width;

                Bitmap padded = Bitmap.createBitmap(
                        width + rowPadding / pixelStride,
                        height,
                        Bitmap.Config.ARGB_8888);

                padded.copyPixelsFromBuffer(buffer);

                Bitmap frame = Bitmap.createBitmap(padded, 0, 0, width, height);
                padded.recycle();

                new Thread(() -> sendFrame(frame), "celular-tv-upload").start();

            } catch (Exception e) {
                sending.set(false);
            } finally {
                if (image != null) image.close();
            }
        }, captureHandler);
    }

    private void sendFrame(Bitmap frame) {
        HttpURLConnection connection = null;
        try {
            ByteArrayOutputStream jpg = new ByteArrayOutputStream();
            frame.compress(Bitmap.CompressFormat.JPEG, 68, jpg);
            byte[] bytes = jpg.toByteArray();

            connection = (HttpURLConnection) new URL(frameUrl).openConnection();
            connection.setConnectTimeout(900);
            connection.setReadTimeout(900);
            connection.setDoOutput(true);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "image/jpeg");
            connection.setFixedLengthStreamingMode(bytes.length);

            OutputStream out = connection.getOutputStream();
            out.write(bytes);
            out.flush();
            out.close();

            connection.getResponseCode();

        } catch (Exception ignored) {
        } finally {
            frame.recycle();
            if (connection != null) connection.disconnect();
            sending.set(false);
        }
    }

    private void stopProjection() {
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        reader = null;

        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        projection = null;

        try {
            if (captureThread != null) captureThread.quitSafely();
        } catch (Exception ignored) {}
        captureThread = null;
        captureHandler = null;
    }

    @Override
    public void onDestroy() {
        stopProjection();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
