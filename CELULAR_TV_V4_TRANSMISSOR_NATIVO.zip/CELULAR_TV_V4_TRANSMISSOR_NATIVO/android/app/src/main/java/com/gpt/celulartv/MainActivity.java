package com.gpt.celulartv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 401;
    private static final int REQ_NOTIF = 402;

    private TextView status;
    private Button transmit;
    private Button retry;
    private MediaProjectionManager projectionManager;
    private volatile String frameUrl = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        transmit = findViewById(R.id.transmit);
        retry = findViewById(R.id.retry);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        transmit.setOnClickListener(v -> {
            if (frameUrl == null) {
                discover();
                return;
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            }
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
        });

        retry.setOnClickListener(v -> discover());

        discover();
    }

    private void discover() {
        frameUrl = null;
        transmit.setEnabled(false);
        status.setText("🔎 Procurando receptor na sua rede Wi‑Fi…");

        new Thread(() -> {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiManager.MulticastLock lock = wm.createMulticastLock("celulartv-discovery");
            lock.setReferenceCounted(false);

            DatagramSocket socket = null;
            try {
                lock.acquire();
                socket = new DatagramSocket();
                socket.setBroadcast(true);
                socket.setSoTimeout(1200);

                byte[] query = "CELULAR_TV_DISCOVER".getBytes(StandardCharsets.US_ASCII);

                String[] targets = new String[]{"255.255.255.255"};
                boolean found = false;

                for (int attempt = 0; attempt < 4 && !found; attempt++) {
                    for (String target : targets) {
                        DatagramPacket p = new DatagramPacket(
                                query, query.length,
                                InetAddress.getByName(target), 8766);
                        socket.send(p);
                    }

                    try {
                        byte[] buf = new byte[256];
                        DatagramPacket answer = new DatagramPacket(buf, buf.length);
                        socket.receive(answer);
                        String text = new String(
                                answer.getData(), 0, answer.getLength(),
                                StandardCharsets.US_ASCII).trim();

                        if (text.startsWith("CELULAR_TV_SERVER|")) {
                            String[] parts = text.split("\\|");
                            if (parts.length >= 3) {
                                final String ip = parts[1];
                                final String port = parts[2];
                                frameUrl = "http://" + ip + ":" + port + "/frame";
                                found = true;
                                runOnUiThread(() -> {
                                    status.setText("🟢 RECEPTOR ENCONTRADO\n" + ip);
                                    transmit.setEnabled(true);
                                });
                            }
                        }
                    } catch (Exception ignored) {}

                    if (!found) Thread.sleep(250);
                }

                if (!found) {
                    runOnUiThread(() -> {
                        status.setText("🟡 Não encontrei o receptor.\nAbra ABRIR_RECEPTOR.bat no PC e toque em PROCURAR NOVAMENTE.");
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("🔴 Falha ao procurar receptor na rede Wi‑Fi."));
            } finally {
                if (socket != null) socket.close();
                try { if (lock.isHeld()) lock.release(); } catch (Exception ignored) {}
            }
        }).start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null && frameUrl != null) {
                Intent service = new Intent(this, CaptureService.class);
                service.putExtra("resultCode", resultCode);
                service.putExtra("projectionData", data);
                service.putExtra("frameUrl", frameUrl);

                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                else startService(service);

                status.setText("🟢 TRANSMISSÃO ATIVA\nAgora volte para o jogo.");
            } else {
                status.setText("🟡 Captura cancelada.");
            }
        }
    }
}
