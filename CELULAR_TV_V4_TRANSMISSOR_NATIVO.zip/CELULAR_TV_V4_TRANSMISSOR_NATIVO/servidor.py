import http.server
import socketserver
import socket
import threading
import time
import os
import json

HTTP_PORT = 8765
DISCOVERY_PORT = 8766
MAGIC = b"CELULAR_TV_DISCOVER"
REPLY = b"CELULAR_TV_SERVER"

BASE = os.path.dirname(os.path.abspath(__file__))
latest_frame = None
last_frame_at = 0.0
frame_lock = threading.Lock()

def local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()

IP = local_ip()

def discovery_server():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("", DISCOVERY_PORT))
    while True:
        try:
            data, addr = s.recvfrom(1024)
            if data.strip() == MAGIC:
                payload = REPLY + b"|" + IP.encode("ascii") + b"|" + str(HTTP_PORT).encode("ascii")
                s.sendto(payload, addr)
        except Exception:
            time.sleep(0.2)

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def no_cache(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")

    def cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(204)
        self.cors()
        self.end_headers()

    def do_POST(self):
        global latest_frame, last_frame_at

        if self.path.split("?", 1)[0] != "/frame":
            self.send_response(404)
            self.end_headers()
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
        except Exception:
            length = 0

        if length <= 0 or length > 8_000_000:
            self.send_response(400)
            self.end_headers()
            return

        data = self.rfile.read(length)
        if not data:
            self.send_response(400)
            self.end_headers()
            return

        with frame_lock:
            latest_frame = data
            last_frame_at = time.time()

        self.send_response(204)
        self.cors()
        self.end_headers()

    def send_file(self, filename, content_type):
        path = os.path.join(BASE, filename)
        data = open(path, "rb").read()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.no_cache()
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = self.path.split("?", 1)[0]

        if path in ("/", "/tv", "/tv.html"):
            self.send_file("tv.html", "text/html; charset=utf-8")
            return

        if path == "/status":
            with frame_lock:
                age = None if not last_frame_at else round(time.time() - last_frame_at, 2)
                active = bool(last_frame_at and (time.time() - last_frame_at) < 2.5)

            body = json.dumps({
                "server": "ok",
                "stream_active": active,
                "last_frame_age": age
            }).encode("utf-8")

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.no_cache()
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if path == "/frame.jpg":
            with frame_lock:
                data = latest_frame

            if not data:
                self.send_response(204)
                self.no_cache()
                self.end_headers()
                return

            self.send_response(200)
            self.send_header("Content-Type", "image/jpeg")
            self.no_cache()
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            try:
                self.wfile.write(data)
            except Exception:
                pass
            return

        self.send_response(404)
        self.end_headers()

if __name__ == "__main__":
    threading.Thread(target=discovery_server, daemon=True).start()

    print()
    print("===================================================")
    print("       CELULAR -> TV V4  |  RECEPTOR ATIVO")
    print("===================================================")
    print(f"TV LG: http://{IP}:{HTTP_PORT}/tv")
    print()
    print("O app Android procura este PC automaticamente.")
    print("Deixe esta janela aberta enquanto estiver jogando.")
    print("===================================================")
    print()

    class ThreadingTCPServer(socketserver.ThreadingTCPServer):
        allow_reuse_address = True
        daemon_threads = True

    with ThreadingTCPServer(("0.0.0.0", HTTP_PORT), Handler) as httpd:
        httpd.serve_forever()
